DEFAULT_API_PATH = "/resource/"
OLD_API_PATH = "/api/views"
DATASETS_PATH = "/api/catalog/v1"
