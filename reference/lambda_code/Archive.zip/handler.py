#!usr/bin/python
import requests
from requests.exceptions import HTTPError
import json


def get_recipients(base_url, token, group):
    """ This function returns the list of xMatters recipients to page"""
    users = []
    if group == 'Demo':
        users.append({'id': 'thompsdm', 'recipientType': 'PERSON'})
    else:
        try:
            url = base_url + '/on-call?groups=' + group
            response = requests.post(url, auth='Bearer: ' + token)
            #logger.info(f"INFO: get_recipients response {response}")
            print(f"INFO: get_recipients response {response}")
            if response.status_code == 200:
                response_json = response.json();
                for data in response_json['data']:
                    for member in data['members']['data']:
                        users.append({'id': member['member']['id'], 'recipientType': member['member']['recipientType']})
        except HTTPError as http_err:
            #logger.info(f"ERROR: Event Failure {http_err}")
            print(f"ERROR: Event Failure {http_err}")
    return users


def get_token():
    """This function handles OAuth authentication to xMatters"""
    token = "Bad Token"
    # Change to SSM later
    token_url = "https://relx-np.hosted.xmatters.com/api/xm/1/oauth2/token"
    client_id = "9d3ec555-bb5c-402b-bb9e-53127eb4e01c"
    username = "NLNSRE"
    password = "NLNSRE"
    grant_type = "password"

    payload = {
        "grant_type": grant_type,
        "client_id": client_id,
        "username": username,
        "password": password,
    }
    try:
        response = requests.post(token_url, json=payload)

        if response.status_code == 200:
            rjson = response.json()
            token = rjson.get("access_token")
            refresh_token = rjson.get("refresh_token")
            #logger.info(f"INFO: OAuth Token Response {response}")
            print(f"INFO: OAuth Token Response {response}")
        else:
            #logger.info(f"ERROR: OAuth Token Failure {response}")
            print(f"ERROR: OAuth Token Failure {response}")
    except HTTPError as http_err:
        print(f"ERROR: HTTP Failure {http_err}")

    return token


def pager(request):
    """ This is the main xMatters pager function.
        Still need an API Endpoint and authentication
        Documentation: https://help.xmatters.com/xmapi/index.html#authentication
    """
    pager_base_url = "https://relx-np.hosted.xmatters.com/api/xm/1"
    trigger_url = pager_base_url + "/functions/782c648d-2e53-4f72-9ba7-1095a6318eb3/triggers"
    auth_token = get_token()
    headers = {'Content-Type': 'application/json',
               'Authorization': 'Bearer ' + auth_token}
    recipients = get_recipients(pager_base_url, auth_token, 'Demo')
    if recipients:
        incident = 'INC00000001'
        comment = "Demo Comment"
        data = {
            "properties": {
                "number": incident,
                "comment": comment
            },
            "recipients": recipients
        }
        data_string = json.dumps(data)
        try:
            response = requests.post(trigger_url, headers=headers, data=data_string, auth=auth_token)
            if response.status_code == 202:
                #logger.info(f"Event triggered: {response.json()['requestId']}")
                print(f"Event triggered: {response.json()['requestId']}")
                return True
            else:
                #logger.info(f"ERROR: Event Failure {str(response.status_code)}")
                print(f"ERROR: Event Failure {str(response.status_code)}")
        except HTTPError as http_err:
            #logger.info(f"ERROR: Event Failure {http_err}")
            print(f"ERROR: Event Failure {http_err}")
    else:
        #logger.info(f"ERROR: {request}")
        print(f"ERROR: {request}")
    return False


def lambda_handler(event, context):
    paged = pager({'Dummy Data'})
    if paged:
        return {
            'statusCode': 200,
            'body': json.dumps('Hello from testPagerLambda!')
        }
    else:
        return {
            'statusCode': 400,
            'body': json.dumps('testPagerLambda Failed!')
        }
